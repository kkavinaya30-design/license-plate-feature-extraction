# PlateVision AI

PlateVision AI is a Python web app for uploading a vehicle image and detecting license plates using the Plate Recognizer Snapshot API.

## Features

- Upload JPG, JPEG, PNG, or WEBP vehicle images
- Send the image to Plate Recognizer for recognition
- Show detected license plate text and confidence scores
- Draw a bounding box around detected plate locations
- Display the raw API response for learning/debugging

## Requirements

- Python 3.10 or newer
- A Plate Recognizer account and API token
- Internet access for API requests

## Run locally

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   python -m streamlit run app.py
   ```

5. Open the local URL shown in the terminal.
6. Enter your Plate Recognizer API token in the sidebar and upload an image.

## API and token safety

The app sends the uploaded image to `https://api.platerecognizer.com/v1/plate-reader/` with the token in the request header. Enter the token at runtime; **do not put it in source code or commit it to GitHub**.

The API requires registration and a token. Availability and request limits depend on the Plate Recognizer account/plan.

## Project status

This repository contains a Python application that integrates with the Plate Recognizer Snapshot API. It is separate from the original PlateVision AI agent created in AshnaAI. It does not claim that the original agent exported or generated this source code.

## Disclaimer

Recognition may be incorrect, especially with blurry, angled, obstructed, or low-resolution images. Use results responsibly and follow applicable privacy and data-protection rules.
