import os
import requests
import streamlit as st
from PIL import Image, ImageDraw

st.set_page_config(page_title="PlateVision AI", page_icon="🚘", layout="wide")

st.title("🚘 PlateVision AI")
st.caption("AI-powered license plate detection and character recognition")
st.write(
    "Upload a vehicle image to detect license plates using the Plate Recognizer Snapshot API. "
    "Recognition requires your own Plate Recognizer API token."
)

with st.sidebar:
    st.header("Settings")
    api_token = st.text_input(
        "Plate Recognizer API token",
        type="password",
        help="Enter your token from your Plate Recognizer account. It is used only for this session."
    )
    region = st.text_input(
        "Region (optional)",
        value="",
        help="Optional region code supported by Plate Recognizer, e.g. us. Leave blank if unsure."
    )
    st.warning("Do not share your API token or commit it to GitHub.")

uploaded_file = st.file_uploader(
    "Upload a vehicle image",
    type=["jpg", "jpeg", "png", "webp"]
)

def recognize_plate(image_bytes, filename, token, region_value):
    url = "https://api.platerecognizer.com/v1/plate-reader/"
    headers = {"Authorization": f"Token {token}"}
    files = {"upload": (filename, image_bytes)}
    data = {}
    if region_value.strip():
        data["regions"] = region_value.strip()
    response = requests.post(url, headers=headers, files=files, data=data, timeout=60)
    if response.status_code == 401:
        raise RuntimeError("Authentication failed. Check your Plate Recognizer API token.")
    if response.status_code == 403:
        raise RuntimeError("The request was forbidden. Check your API token and available credits/plan.")
    response.raise_for_status()
    return response.json()

if uploaded_file:
    image_bytes = uploaded_file.getvalue()
    image = Image.open(uploaded_file).convert("RGB")
    left, right = st.columns([1, 1])
    with left:
        st.subheader("Uploaded image")
        st.image(image, use_container_width=True)

    with right:
        st.subheader("Recognition")
        if st.button("Detect license plate", type="primary"):
            if not api_token.strip():
                st.error("Enter your Plate Recognizer API token in the sidebar first.")
            else:
                try:
                    with st.spinner("Analyzing image..."):
                        result = recognize_plate(
                            image_bytes, uploaded_file.name, api_token.strip(), region
                        )
                    results = result.get("results", [])
                    if not results:
                        st.info("No license plates were detected in this image.")
                    else:
                        st.success(f"Detected {len(results)} license plate result(s).")
                        annotated = image.copy()
                        draw = ImageDraw.Draw(annotated)
                        for item in results:
                            box = item.get("box", {})
                            if all(k in box for k in ("xmin", "ymin", "xmax", "ymax")):
                                draw.rectangle(
                                    [box["xmin"], box["ymin"], box["xmax"], box["ymax"]],
                                    outline="red", width=4
                                )
                        st.image(annotated, caption="Detected plate area(s)", use_container_width=True)
                        for idx, item in enumerate(results, start=1):
                            st.markdown(f"### Result {idx}")
                            st.write("**Plate text:**", item.get("plate", "Not returned"))
                            st.write("**Plate detection confidence:**", item.get("dscore", "Not returned"))
                            st.write("**Character recognition confidence:**", item.get("score", "Not returned"))
                            region_info = item.get("region") or {}
                            if region_info.get("code"):
                                st.write("**Region:**", region_info["code"])
                            vehicle = item.get("vehicle") or {}
                            if vehicle.get("type"):
                                st.write("**Vehicle type:**", vehicle["type"])
                            if item.get("box"):
                                st.write("**Plate bounding box:**", item["box"])
                    with st.expander("View raw API response"):
                        st.json(result)
                except requests.exceptions.Timeout:
                    st.error("The request timed out. Try another image or try again later.")
                except requests.exceptions.RequestException as exc:
                    st.error(f"API request failed: {exc}")
                except RuntimeError as exc:
                    st.error(str(exc))
                except Exception as exc:
                    st.error(f"Could not process the result: {exc}")
else:
    st.info("Choose an image above to get started.")

st.divider()
st.caption(
    "Educational project. Results depend on image quality and the external API. "
    "Do not use recognition output alone to make legal or enforcement decisions."
)
